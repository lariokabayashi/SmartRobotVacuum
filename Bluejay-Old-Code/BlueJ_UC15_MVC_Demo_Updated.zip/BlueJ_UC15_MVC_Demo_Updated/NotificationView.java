public class NotificationView {
    public void showCompletion() {
        System.out.println("Notification: Cleaning complete!");
    }
}