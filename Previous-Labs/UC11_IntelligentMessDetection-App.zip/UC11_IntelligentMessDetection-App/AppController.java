/**
 * Coordinates sensor activation, AI analysis, output to Firmware, and user notification.
 */
public class AppController {
    private UserNotifier notifier;
    private LogManager logger;
    private AppOutputToFirmware output;
    
    public void startCleaningSession() {}
}