/**
 * Handles user responses to app notifications.
 */
public class UserResponseHandler {
    private AppController app;
    public void handleResponse(String response) {}
}