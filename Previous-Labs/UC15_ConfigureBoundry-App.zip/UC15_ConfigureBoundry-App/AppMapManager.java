/**
 * Sends alerts to the end user via app.
 */
public class AppMapManager {
    public String message;

    public void notifyUser(String message) {}
}
