/**
 * Sends alerts to the end user via app.
 */
public class UserNotifier {
    public String message;

    public void notifyUser(String message) {}
}